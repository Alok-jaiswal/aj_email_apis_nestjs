export class CreateEmailtemplateDto {
    template:string
}
